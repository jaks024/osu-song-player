Thanks for downloading! 
you can find the source code on my github at: https://github.com/Jaks01/osu-song-player

How to use
1. click on "Select osu! song folder" button, and select the folder that holds all the song in the osu folder.
2. proceed to "create" tab, name it something, check the box, and create the playlist.
3. After the operation is complete, the playlist will show up and you will be able to play songs.

Tips
You can double click on the name of the song to play. 